"""Core data types — the vocabulary of the pipeline.

Every piece of data that moves between stages has a type defined here, so a
``Detection`` means the same thing to the detector, the ranker, and the tests.
These are the framework-light domain objects: they depend on NumPy only, never
on torch or OpenCV, so the domain layer stays decoupled from any particular
model runtime. Services convert to/from tensors at their own boundaries.

Array conventions (documented once, relied on everywhere):

* Colour images: ``(H, W, 3)`` ``uint8`` in **BGR** order (OpenCV's default).
* Images with alpha (product assets): ``(H, W, 4)`` ``uint8`` **RGBA**.
* Binary masks: ``(H, W)`` ``bool``.
* Depth maps: ``(H, W)`` ``float32`` relative depth (polarity is model-defined
  and normalised by later stages).
* Pixel coordinates: ``x`` is the column, ``y`` is the row; origin top-left.

Small value objects (boxes, points) are frozen dataclasses with ``slots`` for
speed and safety. Types that carry large arrays use ``eq=False`` because
element-wise array comparison is ambiguous and would break the default
``__eq__``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar, Literal

import numpy as np

# Semantic aliases to make signatures self-documenting. These are plain
# ``np.ndarray`` at runtime; the comments state the expected shape and dtype.
ImageBGR = np.ndarray  # (H, W, 3) uint8, BGR
ImageRGBA = np.ndarray  # (H, W, 4) uint8, RGBA
BoolMask = np.ndarray  # (H, W) bool
DepthArray = np.ndarray  # (H, W) float32


@dataclass(frozen=True, slots=True)
class Point2D:
    """A pixel coordinate. ``x`` is the column, ``y`` is the row."""

    x: float
    y: float

    def as_tuple(self) -> tuple[float, float]:
        return (self.x, self.y)


@dataclass(frozen=True, slots=True)
class BoundingBox:
    """An axis-aligned box in pixel coordinates, corners inclusive."""

    x1: float
    y1: float
    x2: float
    y2: float

    def __post_init__(self) -> None:
        if self.x2 < self.x1 or self.y2 < self.y1:
            raise ValueError(
                f"Invalid box: expected x2>=x1 and y2>=y1, got {self.as_xyxy()}"
            )

    @property
    def width(self) -> float:
        return self.x2 - self.x1

    @property
    def height(self) -> float:
        return self.y2 - self.y1

    @property
    def area(self) -> float:
        return self.width * self.height

    @property
    def center(self) -> Point2D:
        return Point2D((self.x1 + self.x2) / 2.0, (self.y1 + self.y2) / 2.0)

    def as_xyxy(self) -> tuple[float, float, float, float]:
        return (self.x1, self.y1, self.x2, self.y2)

    def to_int(self) -> tuple[int, int, int, int]:
        """Return integer pixel corners, for slicing/drawing with OpenCV."""
        return (round(self.x1), round(self.y1), round(self.x2), round(self.y2))


@dataclass(frozen=True, slots=True, eq=False)
class Frame:
    """A single decoded video frame plus its position in time."""

    index: int  # 0-based frame number within the source video
    timestamp: float  # seconds from the start of the video
    image: ImageBGR  # (H, W, 3) uint8, BGR

    def __post_init__(self) -> None:
        if self.image.ndim != 3 or self.image.shape[2] != 3:
            raise ValueError(
                f"Frame.image must be (H, W, 3); got shape {self.image.shape}"
            )

    @property
    def height(self) -> int:
        return int(self.image.shape[0])

    @property
    def width(self) -> int:
        return int(self.image.shape[1])

    @property
    def size(self) -> tuple[int, int]:
        """(width, height) — matches OpenCV's ``(w, h)`` ordering."""
        return (self.width, self.height)


@dataclass(frozen=True, slots=True)
class Detection:
    """One detected region: a box, a text label, and a confidence in [0, 1]."""

    box: BoundingBox
    label: str
    score: float

    def __post_init__(self) -> None:
        if not 0.0 <= self.score <= 1.0:
            raise ValueError(f"Detection.score must be in [0, 1]; got {self.score}")


@dataclass(frozen=True, slots=True, eq=False)
class Mask:
    """A binary segmentation mask over a frame."""

    data: BoolMask  # (H, W) bool
    score: float | None = None  # optional model confidence

    def __post_init__(self) -> None:
        if self.data.ndim != 2:
            raise ValueError(f"Mask.data must be 2-D (H, W); got {self.data.shape}")
        if self.data.dtype != np.bool_:
            raise ValueError(f"Mask.data must be bool; got dtype {self.data.dtype}")

    @property
    def area(self) -> int:
        """Number of pixels set to True."""
        return int(self.data.sum())

    @property
    def bounding_box(self) -> BoundingBox | None:
        """Tight box around the True pixels, or None if the mask is empty."""
        ys, xs = np.where(self.data)
        if ys.size == 0:
            return None
        return BoundingBox(float(xs.min()), float(ys.min()), float(xs.max()), float(ys.max()))


@dataclass(frozen=True, slots=True, eq=False)
class DepthMap:
    """A per-pixel relative depth map for one frame."""

    data: DepthArray  # (H, W) float32

    def __post_init__(self) -> None:
        if self.data.ndim != 2:
            raise ValueError(f"DepthMap.data must be 2-D (H, W); got {self.data.shape}")

    def normalized(self) -> np.ndarray:
        """Min-max scale the depth to [0, 1] for visualization or thresholding."""
        d = self.data.astype(np.float32)
        lo, hi = float(d.min()), float(d.max())
        if hi - lo < 1e-8:
            return np.zeros_like(d)
        return (d - lo) / (hi - lo)


@dataclass(frozen=True, slots=True, eq=False)
class Quad:
    """A quadrilateral placement region: four corners in TL, TR, BR, BL order.

    This is the shape a logo is warped onto. Keeping the corner order fixed lets
    the renderer compute a homography without guessing orientation.
    """

    top_left: Point2D
    top_right: Point2D
    bottom_right: Point2D
    bottom_left: Point2D

    def as_array(self) -> np.ndarray:
        """Return the corners as a ``(4, 2)`` float32 array in TL,TR,BR,BL order."""
        return np.array(
            [
                self.top_left.as_tuple(),
                self.top_right.as_tuple(),
                self.bottom_right.as_tuple(),
                self.bottom_left.as_tuple(),
            ],
            dtype=np.float32,
        )

    @classmethod
    def from_array(cls, corners: np.ndarray) -> "Quad":
        """Build a Quad from a ``(4, 2)`` array in TL,TR,BR,BL order."""
        if corners.shape != (4, 2):
            raise ValueError(f"Quad expects a (4, 2) array; got {corners.shape}")
        tl, tr, br, bl = (Point2D(float(x), float(y)) for x, y in corners)
        return cls(tl, tr, br, bl)

    @classmethod
    def from_box(cls, box: BoundingBox) -> "Quad":
        """Axis-aligned Quad matching a bounding box (a flat starting guess)."""
        return cls(
            top_left=Point2D(box.x1, box.y1),
            top_right=Point2D(box.x2, box.y1),
            bottom_right=Point2D(box.x2, box.y2),
            bottom_left=Point2D(box.x1, box.y2),
        )


@dataclass(frozen=True, slots=True)
class Shot:
    """A continuous camera take: a run of frames with no cut inside it.

    Placement runs per shot; tracking never crosses a shot boundary.
    ``end_frame`` is inclusive.
    """

    index: int
    start_frame: int
    end_frame: int
    start_time: float
    end_time: float

    def __post_init__(self) -> None:
        if self.end_frame < self.start_frame:
            raise ValueError(
                f"Shot {self.index}: end_frame {self.end_frame} < "
                f"start_frame {self.start_frame}"
            )

    @property
    def num_frames(self) -> int:
        return self.end_frame - self.start_frame + 1


@dataclass(frozen=True, slots=True, eq=False)
class ProductAsset:
    """The logo or product PNG to insert, carrying its alpha channel."""

    image: ImageRGBA  # (H, W, 4) uint8, RGBA
    name: str = "product"

    def __post_init__(self) -> None:
        if self.image.ndim != 3 or self.image.shape[2] != 4:
            raise ValueError(
                f"ProductAsset.image must be (H, W, 4) RGBA; got {self.image.shape}"
            )

    @property
    def height(self) -> int:
        return int(self.image.shape[0])

    @property
    def width(self) -> int:
        return int(self.image.shape[1])


@dataclass(frozen=True, slots=True)
class PlacementSpec:
    """How the caller wants a placement chosen.

    The MVP supports only ``"auto"`` (the system picks the best surface). The
    field exists so future modes — ``"prompt"``, ``"box"``, ``"point"`` — slot
    in without changing the pipeline signature. ``target_prompts`` tells the
    open-vocabulary detector what counts as a surface; it is not the user
    choosing a location.
    """

    mode: Literal["auto"] = "auto"
    target_prompts: tuple[str, ...] = (
        "wall",
        "table",
        "floor",
        "billboard",
        "tv screen",
        "poster",
    )


@dataclass(frozen=True, slots=True, eq=False)
class PlacementPlan:
    """The chosen placement on a shot's reference frame.

    Produced by the surface-selection stage: it says *where* on the reference
    frame the product goes. Tracking then propagates this quad across the shot,
    and the renderer fills it.
    """

    shot_index: int
    reference_frame: int
    quad: Quad
    label: str
    score: float
    mask: Mask | None = None
    normal: np.ndarray | None = None  # (3,) surface normal, if depth was used


@dataclass(frozen=True, slots=True, eq=False)
class Track:
    """Raw point trajectories, the native output shape of a point tracker.

    ``points`` is ``(T, N, 2)`` float32 — for each of ``T`` frames, ``N`` points
    in ``(x, y)``. ``visibility`` is ``(T, N)`` bool. ``start_frame`` is the
    frame index the first row corresponds to.
    """

    start_frame: int
    points: np.ndarray  # (T, N, 2) float32
    visibility: np.ndarray  # (T, N) bool

    def __post_init__(self) -> None:
        if self.points.ndim != 3 or self.points.shape[2] != 2:
            raise ValueError(f"Track.points must be (T, N, 2); got {self.points.shape}")
        if self.visibility.shape != self.points.shape[:2]:
            raise ValueError(
                f"Track.visibility {self.visibility.shape} must match "
                f"points[:2] {self.points.shape[:2]}"
            )

    @property
    def num_frames(self) -> int:
        return int(self.points.shape[0])

    @property
    def num_points(self) -> int:
        return int(self.points.shape[1])


@dataclass(frozen=True, slots=True, eq=False)
class PlacementTrack:
    """The placement quad resolved for every frame of a shot.

    This is the tracker's output *interpreted for placement*: one :class:`Quad`
    per frame (from ``start_frame``), plus a per-frame ``visibility`` flag for
    frames where the surface is off-screen or too degenerate to place on.
    """

    start_frame: int
    quads: tuple[Quad, ...]
    visibility: tuple[bool, ...]

    def __post_init__(self) -> None:
        if len(self.quads) != len(self.visibility):
            raise ValueError(
                f"quads ({len(self.quads)}) and visibility "
                f"({len(self.visibility)}) must be the same length"
            )

    @property
    def num_frames(self) -> int:
        return len(self.quads)

    def quad_at(self, frame_index: int) -> Quad | None:
        """Return the quad for an absolute frame index, or None if not visible."""
        offset = frame_index - self.start_frame
        if offset < 0 or offset >= len(self.quads):
            return None
        return self.quads[offset] if self.visibility[offset] else None


# Registry keys are plain strings; this alias documents intent at call sites.
ServiceKey = str
ClassVarStr = ClassVar[str]
