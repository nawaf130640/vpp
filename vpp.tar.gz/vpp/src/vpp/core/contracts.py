"""Model contracts — the interfaces every model must satisfy.

These abstract base classes are the seams that make models replaceable. The
pipeline depends only on ``Detector``, ``Segmenter``, and so on — never on
Grounding DINO or SAM2 directly. A real model and a fake stub both implement
the same contract, so swapping one for the other is a config change, not a code
change. This is the Dependency-Inversion principle made concrete, and it is
what keeps the system from turning into spaghetti as models come and go.

Every contract extends :class:`Service`, which adds a load/unload lifecycle.
CPU and fake services inherit the no-op default; GPU-backed services (added in
Phase 4+) override ``load``/``unload`` so the model manager can free VRAM
between stages.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Sequence
from types import TracebackType
from typing import ClassVar

import numpy as np

from vpp.core.types import (
    BoundingBox,
    Detection,
    DepthMap,
    Frame,
    Mask,
    PlacementTrack,
    ProductAsset,
    Track,
)


class Service(ABC):
    """Base for every model-backed service.

    Manages a simple loaded/unloaded lifecycle. The default ``load``/``unload``
    are no-ops so lightweight (CPU, fake) services need no boilerplate; heavy
    GPU services override them. Instances are usable as context managers, which
    the model manager relies on to guarantee VRAM is released::

        with detector:            # load()
            detector.detect(...)
        # unload() on exit
    """

    name: ClassVar[str] = "service"

    def __init__(self) -> None:
        self._loaded = False

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def load(self) -> None:
        """Acquire resources (e.g. move weights onto the GPU). No-op by default."""
        self._loaded = True

    def unload(self) -> None:
        """Release resources (e.g. free VRAM). No-op by default."""
        self._loaded = False

    def __enter__(self) -> "Service":
        if not self._loaded:
            self.load()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.unload()


class Detector(Service, ABC):
    """Finds candidate regions in a frame, prompted by text labels.

    Backed later by Grounding DINO (open-vocabulary detection).
    """

    name: ClassVar[str] = "detector"

    @abstractmethod
    def detect(self, frame: Frame, prompts: Sequence[str]) -> list[Detection]:
        """Return detections for the given text prompts (e.g. ``["wall"]``).

        Results are ordered by descending score by convention.
        """


class Segmenter(Service, ABC):
    """Produces a precise mask for a region of a frame.

    Backed later by SAM2, prompted with a box from the detector.
    """

    name: ClassVar[str] = "segmenter"

    @abstractmethod
    def segment(self, frame: Frame, box: BoundingBox) -> Mask:
        """Return a binary mask for the object/surface inside ``box``."""


class DepthEstimator(Service, ABC):
    """Estimates per-pixel relative depth for a frame.

    Backed later by Depth Anything V2. Depth feeds surface-planarity ranking and
    the perspective of the placed product.
    """

    name: ClassVar[str] = "depth"

    @abstractmethod
    def estimate(self, frame: Frame) -> DepthMap:
        """Return a relative :class:`DepthMap` for the frame."""


class Tracker(Service, ABC):
    """Follows a set of query points across a sequence of frames.

    Backed later by CoTracker. Used to lock a placement region as the camera
    moves, by tracking the corners (or a grid) of the chosen surface.
    """

    name: ClassVar[str] = "tracker"

    @abstractmethod
    def track(self, frames: Sequence[Frame], queries: np.ndarray) -> Track:
        """Track ``queries`` (an ``(N, 2)`` float32 array of pixel points on
        ``frames[0]``) across all frames, returning a :class:`Track`.
        """


class Renderer(Service, ABC):
    """Composites the product into each frame according to a placement track.

    The MVP backend warps the product with a per-frame homography and alpha-
    composites it (perspective-correct but not relit). A later harmonizer
    (Flux Kontext) implements this same contract for photorealistic blending.
    """

    name: ClassVar[str] = "renderer"

    @abstractmethod
    def render(
        self,
        frames: Sequence[Frame],
        track: PlacementTrack,
        product: ProductAsset,
    ) -> list[Frame]:
        """Return new frames with ``product`` composited per ``track``.

        Frames where the track marks the placement invisible are returned
        unchanged.
        """
